export const studentMock = {
  fullName: "John",
  email: "test@stu.com",
  skills: ["React", "Node.js", "JavaScript", "Git", "TypeScript"],
  educationLevel: "Bachelor",
  fieldOfStudy: "Computer Science",
  institution: "Chulalongkorn University",
  province: "Bangkok",
  phone: "",
  summary: { matches: 12, applications: 2, interviews: 1 }
};

