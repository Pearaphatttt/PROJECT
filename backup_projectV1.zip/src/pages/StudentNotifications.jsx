import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../state/authStore';
import { notificationService } from '../services/notificationService';
import { chatService } from '../services/chatService';
import { Bell, CheckCircle } from 'lucide-react';
import ActionButton from '../components/ActionButton';

const StudentNotifications = () => {
  const navigate = useNavigate();
  const { email } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState('');

  const loadNotifications = useCallback(async () => {
    if (!email) return;
    setLoading(true);
    try {
      const data = await notificationService.getNotifications('student', email);
      const list = Array.isArray(data) ? data : [];

      const filtered = await Promise.all(
        list.map(async (notification) => {
          if (notification.type !== 'message') return notification;
          if (!notification.threadId) return null;
          const ok = await chatService.isParticipantEnabledThread(notification.threadId, email);
          return ok ? notification : null;
        })
      );

      setNotifications(filtered.filter(Boolean));
    } catch (error) {
      console.error('Failed to load notifications:', error);
    } finally {
      setLoading(false);
    }
  }, [email]);

  useEffect(() => {
    loadNotifications();

    const handleStorage = (event) => {
      const key = notificationService.notifKey('student', email);
      if (event.key === key) {
        loadNotifications();
      }
    };

    const handleCustom = (event) => {
      if (event.detail?.role === 'student' && event.detail?.email === email) {
        loadNotifications();
      }
    };

    window.addEventListener('storage', handleStorage);
    window.addEventListener('notifications:changed', handleCustom);
    return () => {
      window.removeEventListener('storage', handleStorage);
      window.removeEventListener('notifications:changed', handleCustom);
    };
  }, [email, loadNotifications]);

  const markNotificationRead = async (id) => {
    if (!email) return;
    try {
      await notificationService.markRead('student', email, id);
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, readAt: Date.now() } : n))
      );
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
    }
  };

  const markAllNotificationsRead = async () => {
    if (!email) return;
    try {
      await notificationService.markAllRead('student', email);
      setNotifications((prev) => prev.map((n) => ({ ...n, readAt: Date.now() })));
    } catch (error) {
      console.error('Failed to mark all as read:', error);
    }
  };

  const handleNotificationClick = async (notification) => {
    setNotice('');
    await markNotificationRead(notification.id);
    if (notification.type === 'message') {
      if (!notification.threadId) {
        setNotice('Chat available after match');
        return;
      }
      const ok = await chatService.isParticipantEnabledThread(notification.threadId, email);
      if (!ok) {
        setNotice('Chat available after match');
        return;
      }
    }

    if (notification.actionUrl) {
      navigate(notification.actionUrl);
      return;
    }
    if (notification.internshipId) {
      if (notification.type === 'match' || notification.type === 'apply') {
        navigate(`/student/internships/${notification.internshipId}`);
      } else if (notification.type === 'message') {
        navigate('/student/chat');
      }
    }
  };

  const handleMarkAllRead = async () => {
    if (!email) return;
    await notificationService.markAllRead('student', email);
    markAllNotificationsRead();
  };

  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    return date.toLocaleDateString();
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'match':
        return <CheckCircle size={20} style={{ color: '#10B981' }} />;
      case 'message':
        return <Bell size={20} style={{ color: '#3F6FA6' }} />;
      default:
        return <Bell size={20} style={{ color: '#6B7C93' }} />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div style={{ color: '#6B7C93' }}>Loading...</div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-10 py-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold" style={{ color: '#2C3E5B' }}>
          Notifications
        </h2>
        {notifications.length > 0 && (
          <ActionButton
            onClick={handleMarkAllRead}
            className="text-sm"
            style={{ background: '#6B7C93' }}
          >
            Mark all as read
          </ActionButton>
        )}
      </div>

      {notice && (
        <div
          className="rounded-xl p-4 mb-4 text-sm"
          style={{
            background: '#FEF3C7',
            color: '#92400E',
            border: '1px solid #FCD34D',
          }}
        >
          {notice}
        </div>
      )}

      {notifications.length === 0 ? (
        <div
          className="rounded-xl p-12 text-center"
          style={{
            background: '#F5F7FB',
            border: '1px solid #D6DEE9',
            boxShadow: '0 4px 12px rgba(15, 23, 42, 0.08)',
          }}
        >
          <Bell size={48} className="mx-auto mb-4" style={{ color: '#CBD5E1' }} />
          <p style={{ color: '#6B7C93' }}>No notifications yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {notifications.map((notification) => {
            const isRead = Boolean(notification.readAt);
            return (
            <button
              key={notification.id}
              onClick={() => handleNotificationClick(notification)}
              className={`w-full text-left rounded-xl p-4 transition-colors ${
                isRead ? 'opacity-60' : ''
              }`}
              style={{
                background: isRead ? '#F5F7FB' : '#FFFFFF',
                border: '1px solid #D6DEE9',
                boxShadow: isRead
                  ? 'none'
                  : '0 4px 12px rgba(15, 23, 42, 0.08)',
              }}
            >
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 mt-1">
                  {getNotificationIcon(notification.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3
                      className={`font-semibold ${isRead ? '' : 'font-bold'}`}
                      style={{ color: '#2C3E5B' }}
                    >
                      {notification.title}
                    </h3>
                    {!isRead && (
                      <div
                        className="w-2 h-2 rounded-full flex-shrink-0 mt-2"
                        style={{ background: '#3F6FA6' }}
                      />
                    )}
                  </div>
                  <p className="text-sm mb-2" style={{ color: '#6B7C93' }}>
                    {notification.message}
                  </p>
                  <div className="text-xs" style={{ color: '#CBD5E1' }}>
                    {formatTime(notification.createdAt)}
                  </div>
                </div>
              </div>
            </button>
          );
          })}
        </div>
      )}
    </div>
  );
};

export default StudentNotifications;

